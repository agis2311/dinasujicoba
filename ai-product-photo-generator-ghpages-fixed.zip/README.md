<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/drive/1Crpi55shpeyzbGNzeESxlLn0DrrV9vbY

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Deploy to GitHub Pages

1) Push to a **public** repo. Default branch: `main`.
2) In **Settings → Secrets and variables → Actions → New repository secret**, add:
   - `VITE_GEMINI_API_KEY` = your Google AI Studio key (note: exposing keys client-side is not secure).
3) (Recommended) In **Settings → Secrets and variables → Actions → Variables**, add:
   - `VITE_BASE_PATH` = `/your-repo-name/`  (for Project Pages). If using a custom domain or user/org root, you can leave it empty or set to `/`.
4) GitHub Pages: **Settings → Pages** → Source: **GitHub Actions**.
5) The included workflow builds `dist/` and deploys it automatically.
6) Single Page App routing: `404.html` is included to help deep links resolve on GitHub Pages.
